package hms.common.events;

import java.io.Serializable;

public class PatientInformationChangedEvent implements Serializable {
}
