package hms.nursingstation.events;

public class InformationChangeReceivedEvent {
}
