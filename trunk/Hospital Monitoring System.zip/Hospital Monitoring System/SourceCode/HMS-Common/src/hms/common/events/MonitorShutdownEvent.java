package hms.common.events;

import java.io.Serializable;

public class MonitorShutdownEvent implements Serializable {
	private static final long serialVersionUID = -3102198770871592500L;
}
