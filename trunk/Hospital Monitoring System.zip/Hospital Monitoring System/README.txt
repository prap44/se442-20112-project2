To run this application:
- Start 'rmiregistry' (found in your JRE bin folder)
- Run HMS-BedsideMonitor.bat
- Run HMS-NursingStation.bat